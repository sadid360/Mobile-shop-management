package Interfaces;

public interface iRegistrationOperation {
    void registration(String textField1, String textField3, String textField2);
}
