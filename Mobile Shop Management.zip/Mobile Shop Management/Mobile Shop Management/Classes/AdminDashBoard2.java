package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static javax.swing.JOptionPane.showMessageDialog;

public class AdminDashBoard2 {

    JFrame frame;
    JLabel label2;
    JLabel lebel2, lebel3, lebel4, lebel5, lebel6, lebel7, lebel10, lebel11, lebel12,lebel99;
    JLabel lf1, lf2, lf3, lf4, lf5, lf6, lf7;
    JTextField field1, field2, field3, field4, field5, field6, field7;
    JButton b1, b2, b3, b4, b12;
    JRadioButton Box1, Box2;
    ButtonGroup bg;

    JComboBox religion;


    AdminDashBoard2(String textField1) {

        frame = new JFrame();
        frame.setUndecorated(true);


        lebel99 = new JLabel();
        lebel99.setIcon(new ImageIcon("Image/Admin3.png"));
        Dimension size = lebel99.getPreferredSize();
        lebel99.setBounds(0, 0, size.width, size.height);


        b1 = new JButton("X");
        b1.setBounds(1180, 4, 30, 40);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b1.setForeground(Color.BLACK);
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b1.setFocusPainted(false);
        b1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b1.setContentAreaFilled(false);

        b2 = new JButton("-");
        b2.setBounds(1150, 1, 25, 30);
        b2.setFont(new Font("Segoe UI", Font.BOLD, 40));
        b2.setForeground(Color.BLACK);
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);
        b2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b2.setContentAreaFilled(false);

        b3 = new JButton();
        b3.setIcon(new ImageIcon("Image/BackButton.png"));
        b3.setBounds(20, 12, 40, 40);
        b3.setForeground(Color.black);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b3.setContentAreaFilled(false);

        b4 = new JButton("Add User");
        b4.setBounds(750, 660, 400, 40);
        b4.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b4.setBackground(Color.LIGHT_GRAY);
        b4.setForeground(Color.black);
        b4.setFocusPainted(false);

        label2 = new JLabel("Add New User");
        label2.setBounds(800, 50, 500, 60);
        label2.setForeground(Color.black);
        label2.setFont(new Font("Segoe UI", Font.BOLD, 40));

        lebel2 = new JLabel("First Name");
        lebel2.setBounds(710, 150, 200, 40);
        lebel2.setForeground(Color.black);
        lebel2.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field1 = new JTextField();
        field1.setBounds(710, 187, 230, 30);
        field1.setForeground(Color.black);
        field1.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field1.setBorder(null);
        field1.setOpaque(false);
        lf1 = new JLabel("___________________________________");
        lf1.setBounds(710, 192, 250, 40);
        lf1.setForeground(Color.black);

        lebel3 = new JLabel("Surname");
        lebel3.setBounds(1010, 150, 200, 40);
        lebel3.setForeground(Color.black);
        lebel3.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field2 = new JTextField();
        field2.setBounds(1010, 187, 180, 30);
        field2.setForeground(Color.black);
        field2.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field2.setBorder(null);
        field2.setOpaque(false);
        lf2 = new JLabel("___________________________");
        lf2.setBounds(1010, 192, 200, 40);
        lf2.setForeground(Color.black);

        lebel4 = new JLabel("Date of Birth (dd/mm/yyyy)");
        lebel4.setBounds(710, 230, 250, 40);
        lebel4.setForeground(Color.black);
        lebel4.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field3 = new JTextField();
        field3.setBounds(710, 265, 230, 30);
        field3.setForeground(Color.black);
        field3.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field3.setBorder(null);
        field3.setOpaque(false);
        lf3 = new JLabel("___________________________________");
        lf3.setBounds(710, 268, 250, 40);
        lf3.setForeground(Color.black);

        lebel5 = new JLabel("Religion");
        lebel5.setBounds(1010, 230, 200, 40);
        lebel5.setForeground(Color.black);
        lebel5.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        String[] option = { "Choose Religion", "Islam", "Hinduism",
                "Christianity", "Sikhism", "Buddhism" };
        religion = new JComboBox(option);
        religion.setBounds(1010, 240, 105, 26);
        religion.setSelectedIndex(0);

        lebel6 = new JLabel("Gender");
        lebel6.setBounds(710, 320, 300, 40);
        lebel6.setForeground(Color.black);
        lebel6.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        bg = new ButtonGroup();

        Box1 = new JRadioButton("Male");
        Box1.setBounds(790, 330, 100, 25);
        Box1.setForeground(Color.black);
        Box1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        Box1.setFocusPainted(false);
        Box1.setBorderPainted(false);
        Box1.setContentAreaFilled(false);

        Box2 = new JRadioButton("Female");
        Box2.setForeground(Color.black);
        Box2.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        Box2.setBounds(890, 330, 100, 25);
        Box2.setFocusPainted(false);
        Box2.setBorderPainted(false);
        Box2.setContentAreaFilled(false);

        lebel7 = new JLabel("Email");
        lebel7.setBounds(710, 365, 300, 40);
        lebel7.setForeground(Color.black);
        lebel7.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field4 = new JTextField();
        field4.setBounds(710, 400, 380, 30);
        field4.setForeground(Color.black);
        field4.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field4.setBorder(null);
        field4.setOpaque(false);
        lf4 = new JLabel("___________________________");
        lf4.setBounds(710, 405, 400, 40);
        lf4.setForeground(Color.black);

        lebel10 = new JLabel("User Name");
        lebel10.setBounds(710, 452, 200, 40);
        lebel10.setForeground(Color.black);
        lebel10.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field5 = new JTextField();
        field5.setBounds(710, 488, 200, 30);
        field5.setForeground(Color.black);
        field5.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field5.setBorder(null);
        field5.setOpaque(false);
        lf5 = new JLabel("_______________________________");
        lf5.setBounds(710, 493, 220, 40);
        lf5.setForeground(Color.black);

        lebel11 = new JLabel("Password");
        lebel11.setBounds(710, 540, 200, 40);
        lebel11.setForeground(Color.black);
        lebel11.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field6 = new JTextField();
        field6.setBounds(710, 580, 200, 30);
        field6.setForeground(Color.black);
        field6.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field6.setBorder(null);
        field6.setOpaque(false);
        lf6 = new JLabel("_______________________________");
        lf6.setBounds(710, 585, 220, 40);
        lf6.setForeground(Color.black);

        lebel12 = new JLabel("Re-type Password");
        lebel12.setBounds(1010, 540, 200, 40);
        lebel12.setForeground(Color.black);
        lebel12.setFont(new Font("Segoe UI", Font.PLAIN, 18));

        field7 = new JTextField();
        field7.setBounds(1010, 580, 200, 30);
        field7.setForeground(Color.black);
        field7.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        field7.setBorder(null);
        field7.setOpaque(false);
        lf7 = new JLabel("___________________________");
        lf7.setBounds(1010, 585, 220, 40);
        lf7.setForeground(Color.black);



        // adding lebel

        frame.add(label2);


        frame.add(lebel2);
        frame.add(lebel3);
        frame.add(lebel4);
        frame.add(lebel5);
        frame.add(lebel6);
        frame.add(lebel7);
        frame.add(lebel10);
        frame.add(lebel11);
        frame.add(lebel12);


        frame.add(field1);
        frame.add(field2);
        frame.add(field3);
        frame.add(field4);
        frame.add(field5);
        frame.add(field6);
        frame.add(field7);


        frame.add(lf1);
        frame.add(lf2);
        frame.add(lf3);
        frame.add(lf4);
        frame.add(lf5);
        frame.add(lf6);
        frame.add(lf7);

        // adding button

        frame.add(b1);
        frame.add(b2);
        frame.add(b3);
        frame.add(b4);

        // r button
        frame.add(Box1);
        frame.add(Box2);
        bg.add(Box1);
        bg.add(Box2);

        // add
        frame.add(lebel99);
        frame.add(religion);

        frame.setSize(1228, 768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setResizable(false);

        // Action
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b1) {
                    frame.setVisible(false);
                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == b2) {
                    frame.setState(Frame.ICONIFIED);
                }

            }
        });

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b3) {
                    new AdminDashBoard(textField1);
                    frame.setVisible(false);
                }
            }
        });

        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String textField1 = field1.getText(); // First Name
                String textField2 = field2.getText(); // Sure Name
                String textField3 = field3.getText(); // Date Of Birth
                String textField4 = field4.getText(); // Email
                String textField5 = field5.getText().toLowerCase(); // User Name
                String textField6 = field6.getText(); // Password
                String textField7 = field7.getText(); // Retype Password

                if (textField1.isEmpty() || textField2.isEmpty() || textField3.isEmpty() || textField4.isEmpty()
                        || textField5.isEmpty() || textField6.isEmpty() || textField7.isEmpty()){
                    showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);

                } else {

                    if (!textField6.equals(textField7)) {
                        showMessageDialog(null, "Password & Re-type Password must be same", "null", 2);
                    }

                    else {

                        try {
                            File file = new File(".\\Data\\user_data.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                            LocalDateTime myDateObj = LocalDateTime.now();
                            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy");

                            String timeAndDate = myDateObj.format(myFormatObj);

                            pw.println("User Name : " + textField5);
                            pw.println("Password : " + textField6);
                            pw.println("Email : " + textField4);
                            pw.println("Time & Date : " + timeAndDate);
                            pw.println("===============================================");
                            pw.close();

                            showMessageDialog(null,
                                    "User Added Successfully",
                                    "Registration Complete", JOptionPane.WARNING_MESSAGE);
                            new AdminDashBoard2(textField1);
                            frame.setVisible(false);

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }
                    }
                }
            }
        });

    }
}
