package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.JOptionPane.showMessageDialog;

public class ForgotPass2 {
    JFrame f1, f2;
    JPanel p1;
    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16;
    JTextField tf1, tf2, tf3, tf4;
    JButton b1, b2, b3, b4;
    JCheckBox c1;
    JComboBox securityQsn;
    ImageIcon i1;

    ForgotPass2() {

        f1 = new JFrame();
        f1.setUndecorated(true);

//        i1 = new ImageIcon("image/logo.png");
//        f1.setIconImage(i1.getImage());

//
        l1 = new JLabel();
        l1.setIcon(new ImageIcon("Image/Forgot.png"));
        Dimension size = l1.getPreferredSize();
        l1.setBounds(0, 0, size.width, size.height);

        l2 = new JLabel("Enter Recovery Code");
        l2.setBounds(150, 120, 600, 70);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("SansSerif", Font.BOLD, 50));

        l3 = new JLabel("Check your email.You must receive an email with");
        l3.setBounds(150, 170, 600, 70);
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("SansSerif", Font.BOLD, 18));

        l4 = new JLabel("recovery code for password reset");
        l4.setBounds(150, 200, 600, 70);
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("SansSerif", Font.BOLD, 18));

        l5 = new JLabel("Didn't receive code?");
        l5.setBounds(150, 350, 300, 70);
        l5.setForeground(Color.WHITE);
        l5.setFont(new Font("SansSerif", Font.BOLD, 18));


        tf1 = new JTextField();
        tf1.setBounds(150, 300, 300, 40);
        tf1.setFont(new Font("SansSerif", Font.PLAIN, 18));
        tf1.setForeground(Color.BLACK);
        tf1.setBackground(new Color(231,231,231,255));
        tf1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        tf1.setCaretColor(Color.BLACK);

        b1 = new JButton("X");
        b1.setBounds(1180, 4, 30, 40);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b1.setForeground(Color.black);
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b1.setFocusPainted(false);
        b1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b1.setContentAreaFilled(false);

        b2 = new JButton("-");
        b2.setBounds(1150, 1, 25, 30);
        b2.setFont(new Font("Segoe UI", Font.BOLD, 40));
        b2.setForeground(Color.black);
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);
        b2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b2.setContentAreaFilled(false);

        b3 = new JButton();
        b3.setIcon(new ImageIcon("Image/BackButton.png"));
        b3.setBounds(20, 12, 40, 40);
        b3.setForeground(Color.black);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b3.setContentAreaFilled(false);

        b4 = new JButton("Send Again");
        b4.setBounds(340, 371, 135, 25);
        b4.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b4.setForeground(Color.white);
        b4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b4.setFocusPainted(false);
        b4.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b4.setContentAreaFilled(false);






        // adding lebel
        f1.add(l2);
        f1.add(l3);
        f1.add(l4);
        f1.add(l5);

        // adding text field
       f1.add(tf1);
//        f1.add(tf2);
        // f1.add(tf3);
//        f1.add(tf4);

        // adding button
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.add(b4);

        // add
        f1.add(l1);
//

        f1.setSize(1228, 768);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLocationRelativeTo(null);
        f1.setLayout(null);
        f1.setVisible(true);
        f1.setResizable(false);

        // Action

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b1) {
                    f1.setVisible(false);
                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b2) {
                    f1.setState(Frame.ICONIFIED);
                }

            }
        });

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b3) {
                    new Login("textField1", "textField2");
                    f1.setVisible(false);
                }
            }
        });

        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b4) {
                    showMessageDialog(null, "Recovery code is sent to your email!", "Message", -1);

                }
            }
        });








    }
}
