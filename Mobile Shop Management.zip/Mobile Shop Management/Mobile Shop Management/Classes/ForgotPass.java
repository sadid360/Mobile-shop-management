package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;

import static javax.swing.JOptionPane.showMessageDialog;

public class ForgotPass {
    JFrame f1, f2;
    JPanel p1;
    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16;
    JTextField tf1, tf2, tf3, tf4;
    JButton b1, b2, b3, b4,b5;
    JCheckBox c1;
    JComboBox securityQsn;
    ImageIcon i1;

    ForgotPass() {

        f1 = new JFrame();
        f1.setUndecorated(true);

//        i1 = new ImageIcon("image/logo.png");
//        f1.setIconImage(i1.getImage());

//
        l1 = new JLabel();
        l1.setIcon(new ImageIcon("Image/Forgot.png"));
        Dimension size = l1.getPreferredSize();
        l1.setBounds(0, 0, size.width, size.height);

        l2 = new JLabel("Forgot Password");
        l2.setBounds(150, 120, 600, 70);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("SansSerif", Font.BOLD, 50));

        l3 = new JLabel("Enter your e-mail address,and we'll give you reset instruction  ");
        l3.setBounds(110, 170, 600, 70);
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("SansSerif", Font.BOLD, 18));

        l4 = new JLabel("User Name");
        l4.setBounds(150, 250, 300, 70);
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("SansSerif", Font.BOLD, 20));

        l5 = new JLabel("Email");
        l5.setBounds(150, 340, 300, 70);
        l5.setForeground(Color.WHITE);
        l5.setFont(new Font("SansSerif", Font.BOLD, 20));

        l6 = new JLabel("Already have an account?");
        l6.setBounds(150, 520, 300, 70);
        l6.setForeground(Color.WHITE);
        l6.setFont(new Font("SansSerif", Font.BOLD, 20));


        //username textfile
        tf1 = new JTextField();
        tf1.setBounds(150, 310, 300, 40);
        tf1.setFont(new Font("SansSerif", Font.PLAIN, 18));
        tf1.setForeground(Color.BLACK);
        tf1.setBackground(new Color(231,231,231,255));
        tf1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        tf1.setCaretColor(Color.BLACK);

        //email textfield
        tf2 = new JTextField();
        tf2.setBounds(150, 400, 300, 40);
        tf2.setFont(new Font("SansSerif", Font.PLAIN, 18));
        tf2.setForeground(Color.BLACK);
        tf2.setBackground(new Color(231,231,231,255));
        tf2.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        tf2.setCaretColor(Color.BLACK);


        b1 = new JButton("X");
        b1.setBounds(1180, 4, 30, 40);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b1.setForeground(Color.black);
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b1.setFocusPainted(false);
        b1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b1.setContentAreaFilled(false);

        b2 = new JButton("-");
        b2.setBounds(1150, 1, 25, 30);
        b2.setFont(new Font("Segoe UI", Font.BOLD, 40));
        b2.setForeground(Color.black);
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);
        b2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b2.setContentAreaFilled(false);

        b3 = new JButton();
        b3.setIcon(new ImageIcon("Image/BackButton.png"));
        b3.setBounds(20, 12, 40, 40);
        b3.setForeground(Color.black);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b3.setContentAreaFilled(false);

        b4 = new JButton("Login");
        b4.setBounds(390, 530, 130, 45);
        b4.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b4.setForeground(Color.white);
        b4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b4.setFocusPainted(false);
        b4.setBorder(BorderFactory.createEmptyBorder());
        b4.setContentAreaFilled(false);
        b4.setOpaque(false);

        b5 = new JButton("Send New Password");
        b5.setBounds(150, 470, 300, 45);
        b5.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b5.setForeground(Color.WHITE);
        b5.setBackground(new Color(194, 5, 246,255));
        b5.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b5.setFocusPainted(false);
        b5.setBorder(BorderFactory.createEmptyBorder());
        b5.setContentAreaFilled(true);
        b5.setOpaque(true);







        // adding lebel
        f1.add(l2);
        f1.add(l3);
        f1.add(l4);
        f1.add(l5);
        f1.add(l6);
//

        // adding text field
        f1.add(tf1);
        f1.add(tf2);
        // f1.add(tf3);
//        f1.add(tf4);

        // adding button
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.add(b4);
        f1.add(b5);

        // add
        f1.add(l1);
//        f1.add(securityQsn);
//        f1.add(p1);

        f1.setSize(1228, 768);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLocationRelativeTo(null);
        f1.setLayout(null);
        f1.setVisible(true);
        f1.setResizable(false);

        // Action

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b1) {
                    f1.setVisible(false);
                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b2) {
                    f1.setState(Frame.ICONIFIED);
                }

            }
        });

        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String textField1 = tf1.getText();
                String textField00 = tf2.getText();


                if (e.getSource() == b5) {
                    if ( !textField1.isEmpty()
                            && !textField00.isEmpty()) {

                        try {
                            String userNameS = "User Name : " + textField1;
                            String email = "Email : " + textField00;
                            BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_data.txt"));

                            int totalLines = 0;
                            while (reader.readLine() != null)
                                totalLines++;
                            reader.close();

                            for (int i = 0; i <= totalLines; i++) {
                                String line = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get(i);
                                if (line.equals(userNameS)) {
                                    String line2 = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get((i + 2));
                                    if (line2.equals(email)) {
                                        new ForgotPass2();
                                        f1.setVisible(false);
                                        break;
                                    }
                                }
                            }

                        } catch (Exception ex) {
                            showMessageDialog(null, " User Not Found or Wrong email",
                                    "Message", -1);


                        }

                    } else {
                        showMessageDialog(null, "Please fill all of the fields.", "Warning!", 2);
                    }
                }
            }
        });

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b3) {
                    new Login("textField1", "textField2");
                    f1.setVisible(false);
                }
            }
        });

        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b4) {
                    new Login("textField1", "textField2");
                    f1.setVisible(false);

                }
            }
        });







    }
}
