package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage extends JFrame {
    JFrame f1;
    JLabel l1;
    JButton b1, b2, b3, b4,b5;
    ImageIcon i1;

    public HomePage() {

        f1 = new JFrame();
        f1.setUndecorated(true); // frame er oporer border remove kore
//        f1.setBounds(0, 0, 100, 100); // screen a box/frame er position set kore

//        i1 = new ImageIcon("image/logo.png");
//        f1.setIconImage(i1.getImage());

        l1 = new JLabel();
        l1.setIcon(new ImageIcon("Image/Home.png")); //image set kore
        Dimension size = l1.getPreferredSize(); // oporer ai image er jei size ace like (1200 x 700 )ota nai and save rakhe size variable a
        l1.setBounds(0, 0, size.width, size.height); // image er oi size tai akhane use kore size.width and size.height diye

        b1 = new JButton("X");
        b1.setBounds(1180, 4, 30, 40);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 25)); //"x" ai lakha tar front set kore
        b1.setForeground(Color.WHITE); // X ai word tar color ki hobe ata set kore
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR)); // X er opore mouse/cursor niye gele akta hand cursor show kore
        b1.setFocusPainted(false); // X button er char pase blue color square box er color ta remove kore
        b1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4)); // empty space/padding add kore X button er char pase
        b1.setContentAreaFilled(false); //default background color remove kore button ke transparent korar jonne

        b2 = new JButton("-");
        b2.setBounds(1150, 1, 25, 30);
        b2.setFont(new Font("Segoe UI", Font.BOLD, 40));
        b2.setForeground(Color.WHITE);
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);
        b2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b2.setContentAreaFilled(false);

        b3 = new JButton("Login");
        b3.setBounds(980, 53, 86, 45);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b3.setForeground(Color.WHITE);
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder());
        b3.setContentAreaFilled(false);
        b3.setOpaque(false);//opacity  or transparent korar jonne use kora ho


        b4 = new JButton("Sign Up");
        b4.setBounds(1065, 52, 100, 45);
        b4.setFont(new Font("Segoe UI", Font.BOLD, 18));
        b4.setForeground(Color.WHITE);
        b4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b4.setFocusPainted(false);
        b4.setBorder(BorderFactory.createEmptyBorder());
        b4.setContentAreaFilled(false);
        b4.setOpaque(false);

        b5 = new JButton(" Team Contribution");
        b5.setBounds(1000, 650, 200, 45);
        b5.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b5.setForeground(Color.WHITE);
        b5.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b5.setFocusPainted(false);
        b5.setBorder(BorderFactory.createEmptyBorder());
        b5.setContentAreaFilled(false);
        b5.setOpaque(false);


        f1.add(b1);// x/b1 button ke frame er sathe add korce
        f1.add(b2);
        f1.add(b3);
        f1.add(b4);
        f1.add(b5);
        f1.add(l1);

        f1.setSize(1228, 768); //frame er size set korce
        f1.setLocationRelativeTo(null); // frame ke screen er center  bosacce
        f1.setLayout(null); //jframe er layout management ke disable kore jate kore components ke manually set kore jai
        f1.setVisible(true); // frame ke visible kore.N.B. Most important line in the code. Without this setVisible(true), the frame won't show up
        f1.setResizable(false); // frame ke jano resize/ choto boro na kora jai tai false kora hoice
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //frame er x button click korai jano program close hoi

        // button er action ke listen korar jonno use hoi
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b1) {
                    f1.setVisible(false);
                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b2) {
                    f1.setState(Frame.ICONIFIED);
                }
            }
        });


        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == b3) {
                    new Login("textField1", "textField2");
                    f1.setVisible(false);

                }
            }
        });

        b4.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b4) {
                    new Registration("textField1","textField3", "textField2");
                    f1.setVisible(false);
                }

            }
        });

        b5.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                if(e.getSource() == b5){
                    new Contribution();
                    f1.setVisible(false);
                }

            }
        });

    }
}
