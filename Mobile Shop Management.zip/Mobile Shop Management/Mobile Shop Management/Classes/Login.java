package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.JOptionPane.showMessageDialog;

public class Login extends logC {
    JFrame f1;
    JPanel p1;
    JPanel p2;
    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12;
    JTextField tf1;
    JPasswordField pf1;
    JButton b1, b2, b3, b4, b5, b6, b7, b8, b9;
    JCheckBox c1;
    JComboBox religion;
    ImageIcon i1;
    JRadioButton r1, r2;
    ButtonGroup bg1;
    int pc = 0;

    Login(String textField1, String textField2) {
        super(textField1, textField2);

        f1 = new JFrame();
        f1.setUndecorated(true);

//        i1 = new ImageIcon("image/logo.png");
//        f1.setIconImage(i1.getImage());

        l8 = new JLabel();
        l8.setIcon(new ImageIcon("Image/Login.png"));
        Dimension size = l8.getPreferredSize();
        l8.setBounds(0, 0, size.width, size.height);

        tf1 = new JTextField();
        tf1.setBounds(92, 270, 340, 40);
        tf1.setFont(new Font("SansSerif", Font.PLAIN, 17));
        tf1.setForeground(Color.BLACK);
        tf1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        tf1.setCaretColor(Color.black);

        pf1 = new JPasswordField();
        pf1.setBounds(92, 370, 340, 40);
        pf1.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        pf1.setForeground(Color.BLACK);
        pf1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        pf1.setCaretColor(Color.black);

        c1 = new JCheckBox("Remember me");
        c1.setBounds(92, 450, 220, 40);
        c1.setFont(new Font("SansSerif", Font.PLAIN, 18));
        c1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        c1.setForeground(Color.white);
        c1.setFocusPainted(false);
        c1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        c1.setContentAreaFilled(false);


        b1 = new JButton("X");
        b1.setBounds(1180, 4, 30, 40);
        b1.setForeground(Color.BLACK);
        b1.setBackground(new Color(255, 166, 210, 255));
        b1.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b1.setFocusPainted(false);
        b1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b1.setContentAreaFilled(false);

        l1 = new JLabel("Welcome");
        l1.setBounds(780, 80, 400, 60);
        l1.setForeground(Color.white);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 45));

        l2 = new JLabel("Login in to your account to continue");
        l2.setBounds(720, 130, 700, 40);
        l2.setForeground(Color.white);
        l2.setFont(new Font("Segoe UI", Font.PLAIN, 20));


        l3 = new JLabel("Login");
        l3.setBounds(180, 80, 300, 70);
        l3.setForeground(Color.white);
        l3.setFont(new Font("SansSerif", Font.BOLD, 50));

        l4 = new JLabel("User Name");
        l4.setBounds(98, 240, 150, 35);
        l4.setForeground(Color.white);
        l4.setFont(new Font("SansSerif", Font.PLAIN, 20));

        l5 = new JLabel("Password");
        l5.setBounds(98, 340, 150, 35);
        l5.setForeground(Color.white);
        l5.setFont(new Font("SansSerif", Font.PLAIN, 20));

        b2 = new JButton("Forgot Password?");
        b2.setBounds(233, 405, 230, 40);
        b2.setForeground(Color.white);
        b2.setFont(new Font("SansSerif", Font.PLAIN, 20));
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);
        b2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b2.setContentAreaFilled(false);

        l9 = new JLabel("Don't have an account?");
        l9.setBounds(95, 630, 240, 40);
        l9.setForeground(Color.white);
        l9.setFont(new Font("SansSerif", Font.PLAIN, 20));

        b5 = new JButton("Sign Up");
        b5.setBounds(300, 625, 110, 45);
        b5.setFont(new Font("Segoe UI", Font.BOLD, 22));
        b5.setForeground(Color.WHITE);
        b5.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b5.setFocusPainted(false);
        b5.setBorder(BorderFactory.createEmptyBorder());
        b5.setContentAreaFilled(false);
        b5.setOpaque(false);

        b3 = new JButton("Login");
        b3.setBounds(92, 500, 350, 45);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 27));
        b3.setForeground(Color.WHITE);
        b3.setBackground(new Color(204, 129, 225,255));
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder());
        b3.setContentAreaFilled(true);
        b3.setOpaque(true);


        b7 = new JButton("-");
        b7.setBounds(1150, 1, 25, 30);
        b7.setForeground(Color.BLACK);
        b7.setBackground(new Color(255, 166, 210, 255));
        b7.setFont(new Font("Segoe UI", Font.BOLD, 40));
        b7.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b7.setFocusPainted(false);
        b7.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b7.setContentAreaFilled(false);


        b8 = new JButton();
        b8.setIcon(new ImageIcon("Image/BackButton.png"));
        b8.setBounds(20, 12, 40, 40);
        b8.setForeground(Color.black);
        b8.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b8.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b8.setFocusPainted(false);
        b8.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b8.setContentAreaFilled(false);

        bg1 = new ButtonGroup();



        r1 = new JRadioButton("Admin Login");
        r1.setBounds(250, 170, 180, 25);
        r1.setFont(new Font("SansSerif", Font.PLAIN, 20));
        r1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        r1.setForeground(Color.white);
        r1.setBorderPainted(false);
        r1.setContentAreaFilled(false);
        r1.setFocusPainted(false);

        r2 = new JRadioButton("User Login");
        r2.setBounds(100, 170, 180, 25);
        r2.setFont(new Font("SansSerif", Font.PLAIN, 20));
        r2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        r2.setForeground(Color.white);
        r2.setBorderPainted(false);
        r2.setContentAreaFilled(false);
        r2.setFocusPainted(false);

        f1.add(l1);
        f1.add(l2);
        f1.add(l3);
        f1.add(l4);
        f1.add(l5);
        f1.add(tf1);
        f1.add(pf1);
        f1.add(c1);
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.add(b5);
        f1.add(b7);
        f1.add(b8);
        f1.add(r1);
        f1.add(r2);
        f1.add(l9);
        f1.add(l8);


//         f1.add(bg1);
        bg1.add(r1);
        bg1.add(r2);

        f1.setSize(1228, 768);
        f1.setLocationRelativeTo(null);
        f1.setLayout(null);
        f1.setVisible(true);
        f1.setResizable(false);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b1) {
                    f1.setVisible(false);
                }
            }
        });

        b7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b7) {
                    f1.setState(Frame.ICONIFIED);

                }
            }
        });


        b8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b8) {
                   new HomePage();
                   f1.setVisible(false);
                   // f1.dispose();

                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b2) {
                    new ForgotPass();
                    f1.setVisible(false);

                }
            }
        });

        r1 .addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == r1) {
                    pc = 1;
                }
            }
        });

        r2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == r2) {
                    pc = 2;
                }
            }
        });


        b3.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {

                String textField1 = tf1.getText().toLowerCase(); // User Name
                String textField2 = pf1.getText(); // Password
                if (pc == 1) {
                    if ((!textField1.isEmpty() && !textField2.isEmpty())) {

                        matchAdmin(textField1, textField2);

                        if (s == 1) {
                            f1.setVisible(false);
                        }

                    } else {
                        showMessageDialog(null, " Fill the blank fields ", "Message", -1);
                    }
                }

                else if (pc == 2) {

                    if (!textField1.isEmpty() && !textField2.isEmpty()) {

                        matchUser(textField1, textField2);

                        if (s == 2) {
                            f1.setVisible(false);
                        }

                    } else {
                        showMessageDialog(null, " Fill the blank fields ", "Message", -1);
                    }

                } else if (pc != 2 || pc != 1) {
                    showMessageDialog(null, " Choose User type ", "Message", -1);
                }

            }
        });




        b5.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                if(e.getSource() == b5){
                    new Registration("textField1","textField3","textField2");
                    f1.setVisible(false);
                }

            }
        });


    }

}
