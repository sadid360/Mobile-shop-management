package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.JOptionPane.showMessageDialog;


public class Registration extends registrationC {

    JFrame frame1;
    JPanel panel1;
    JLabel lebel1, lebel2, lebel3, lebel4, lebel5, lebel6, lebel7, lebel8, lebel9, lebel10, lebel11, lebel12, lebel13,
            lebel14, lebel15, lebel16, lebel17, lebel18, lebel19,
            lebel99;
    JLabel lf1, lf2, lf3, lf4, lf5, lf6, lf7, lf8, lf9;
    JTextField field1, field2, field3, field4, field5, field6, field7, field8, field9;
    JPasswordField pass1, pass2;
    JButton button1, button2, button3, button4, button5;
    JRadioButton Box1, Box2, Box3;
    ButtonGroup bg;
    JCheckBox c;
    JComboBox religion, securityQsn;
    ImageIcon i1;

    Registration(String textField1, String textField3, String textField2) {
        super(textField1, textField3, textField2);

        frame1 = new JFrame();
        frame1.setUndecorated(true);

//        i1 = new ImageIcon("image/logo.png");
//        frame1.setIconImage(i1.getImage());

//
        button1 = new JButton("X");
        button1.setBounds(1180, 4, 30, 40);
        button1.setFont(new Font("Segoe UI", Font.BOLD, 25)); //"x" ai lakha tar front set kore
        button1.setForeground(Color.WHITE); // X ai word tar color ki hobe ata set kore
        button1.setCursor(new Cursor(Cursor.HAND_CURSOR)); // X er opore mouse/cursor niye gele akta hand cursor show kore
        button1.setFocusPainted(false); // X button er char pase blue color square box er color ta remove kore
        button1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4)); // empty space/padding add kore X button er char pase
        button1.setContentAreaFilled(false); //default background color remove kore button ke transparent korar jonne


        button3 = new JButton("-");
        button3.setBounds(1150, 1, 25, 30);
        button3.setFont(new Font("Segoe UI", Font.BOLD, 40));
        button3.setForeground(Color.WHITE);
        button3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button3.setFocusPainted(false);
        button3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        button3.setContentAreaFilled(false);


        button4 = new JButton();
        button4.setIcon(new ImageIcon("Image/BackButton.png"));
        button4.setBounds(20, 12, 40, 40);
        button4.setForeground(Color.black);
        button4.setFont(new Font("Segoe UI", Font.BOLD, 20));
        button4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button4.setFocusPainted(false);
        button4.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        button4.setContentAreaFilled(false);

        lebel1 = new JLabel("Sign Up");
        lebel1.setBounds(180, 80, 300, 70);
        lebel1.setForeground(new Color(56, 3, 97, 255));
        lebel1.setFont(new Font("SansSerif", Font.BOLD, 50));

        lebel2 = new JLabel("User Name");
        lebel2.setBounds(98, 243, 150, 35);
        lebel2.setForeground(Color.BLACK);
        lebel2.setFont(new Font("SansSerif", Font.PLAIN, 18));

        lebel3 = new JLabel("Email");
        lebel3.setBounds(98, 343, 150, 35);
        lebel3.setForeground(Color.BLACK);
        lebel3.setFont(new Font("SansSerif", Font.PLAIN, 18));

        lebel4 = new JLabel("Password");
        lebel4.setBounds(98, 443, 150, 35);
        lebel4.setForeground(Color.BLACK);
        lebel4.setFont(new Font("SansSerif", Font.PLAIN, 18));

        lebel5 = new JLabel("Confirm Password");
        lebel5.setBounds(300, 443, 200, 35);
        lebel5.setForeground(Color.BLACK);
        lebel5.setFont(new Font("SansSerif", Font.PLAIN, 18));

        lebel6 = new JLabel("Already have an account?");
        lebel6.setBounds(98, 650, 240, 40);
        lebel6.setForeground(Color.BLACK);
        lebel6.setFont(new Font("SansSerif", Font.PLAIN, 20));


        //username textfield
        field1 = new JTextField();
        field1.setBounds(98, 280, 390, 45);
        field1.setFont(new Font("SansSerif", Font.PLAIN, 18));
        field1.setForeground(Color.BLACK);
        field1.setBackground(new Color(231, 231, 231, 255));
        field1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        field1.setCaretColor(Color.BLACK);

        //email
        field2 = new JTextField();
        field2.setBounds(98, 380, 390, 45);
        field2.setFont(new Font("SansSerif", Font.PLAIN, 18));
        field2.setForeground(Color.BLACK);
        field2.setBackground(new Color(231, 231, 231, 255));
        field2.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        field2.setCaretColor(Color.BLACK);

        //pass
        pass1 = new JPasswordField();
        pass1.setBounds(98, 480, 190, 45);
        pass1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        pass1.setForeground(Color.BLACK);
        pass1.setBackground(new Color(231, 231, 231, 255));
        pass1.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        pass1.setCaretColor(Color.BLACK);

        //confirm pass
        pass2 = new JPasswordField();
        pass2.setBounds(300, 480, 190, 45);
        pass2.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        pass2.setForeground(Color.BLACK);
        pass2.setBackground(new Color(231, 231, 231, 255));
        pass2.setCursor(new Cursor(Cursor.TEXT_CURSOR));
        pass2.setCaretColor(Color.BLACK);

        button2 = new JButton("Create Account");
        button2.setBounds(98, 580, 390, 45);
        button2.setFont(new Font("Segoe UI", Font.BOLD, 27));
        button2.setForeground(Color.WHITE);
        button2.setBackground(new Color(56, 3, 97, 255));
        button2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button2.setFocusPainted(false);
        button2.setBorder(BorderFactory.createEmptyBorder());
        button2.setContentAreaFilled(true);


        button5 = new JButton("Login");
        button5.setBounds(320, 647, 110, 45);
        button5.setFont(new Font("Segoe UI", Font.BOLD, 25));
        button5.setForeground(Color.BLACK);
        button5.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button5.setFocusPainted(false);
        button5.setBorder(BorderFactory.createEmptyBorder());
        button5.setContentAreaFilled(false);
        button5.setOpaque(false);


        lebel99 = new JLabel();
        lebel99.setIcon(new ImageIcon("Image/SignUp.png"));
        Dimension size = lebel99.getPreferredSize();
        lebel99.setBounds(0, 0, size.width, size.height);

        // adding all level
        frame1.add(lebel1);
        frame1.add(lebel2);
        frame1.add(lebel3);
        frame1.add(lebel4);
        frame1.add(lebel5);
        frame1.add(lebel6);
//
//
//        // adding all button
        frame1.add(button1);
        frame1.add(button2);
        frame1.add(button3);
        frame1.add(button4);
        frame1.add(button5);
//
//        // adding all text field
        frame1.add(field1);
        frame1.add(field2);
        frame1.add(pass1);
        frame1.add(pass2);

        // adding panel
        frame1.add(lebel99);
//        frame1.add(panel1);

        frame1.setSize(1228, 768);
        frame1.setLayout(null);
        frame1.setLocationRelativeTo(null);
        frame1.setVisible(true);

        // Action Listener
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == button1) {
                    if (e.getSource().equals(button1)) {

                        frame1.setVisible(false);
                    }
                }
            }
        });

        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String textField1 = field1.getText().toLowerCase(); // User name
                String textField2 = field2.getText(); // email
                String textField3 = pass1.getText(); // pass
                String textField4 = pass2.getText(); // confirm pass
                int result = 0;

                if (textField1.isEmpty() || textField2.isEmpty() || textField3.isEmpty() || textField4.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);

                } else {

                    if (!textField3.equals(textField4)) {
                        showMessageDialog(null, "Password & Confirm Password must be same", "null", 2);
                    } else {

                        registration(textField1, textField3, textField2);

                        if (s == 1) {
                            frame1.setVisible(false);
                        }

                    }
                }
            }
            });

        button3.addActionListener(new

            ActionListener() {
                public void actionPerformed (ActionEvent e){

                    if (e.getSource() == button3) {
                        if (e.getSource().equals(button3)) {

                            frame1.setState(frame1.ICONIFIED);

                        }
                    }
                }
            });

        button4.addActionListener(new

            ActionListener() {
                public void actionPerformed (ActionEvent e){

                    if (e.getSource() == button4) {
                        new Login("textField1", "textField2");
                        frame1.setVisible(false);
                    }
                }
            });

        button5.addActionListener(new

            ActionListener() {
                public void actionPerformed (ActionEvent e){

                    if (e.getSource() == button5) {
                        new Login("textField1", "textField2");
                        frame1.setVisible(false);
                    }
                }
            });

        }
    }
