package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashBoard extends JFrame {

    JFrame frame;

    JLabel l1;
    JButton b1, b2, b3, b4, b5, b6;
    JButton pl1, pl2, pl3;


    AdminDashBoard(String textField1) {

        frame = new JFrame();
        frame.setUndecorated(true);


        l1 = new JLabel();
        l1.setIcon(new ImageIcon("Image/Admin.png"));
        Dimension size = l1.getPreferredSize();
        l1.setBounds(0, 0, size.width, size.height);

        b1 = new JButton("X");
        b1.setBounds(1180, 1, 30, 40);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b1.setForeground(Color.black);
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b1.setFocusPainted(false);
        b1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b1.setContentAreaFilled(false);

        b2 = new JButton("-");
        b2.setBounds(1150, 1, 25, 30);
        b2.setFont(new Font("Segoe UI", Font.BOLD, 40));
        b2.setForeground(Color.black);
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);
        b2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b2.setContentAreaFilled(false);

        b3 = new JButton();
        b3.setIcon(new ImageIcon("Image/BackButton.png"));
        b3.setBounds(20, 12, 40, 40);
        b3.setForeground(Color.black);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b3.setContentAreaFilled(false);

        b4 = new JButton();
        b4.setBounds(80, 100, 210, 190);
        b4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b4.setFocusPainted(false);
        b4.setBorder(BorderFactory.createEmptyBorder());
        b4.setContentAreaFilled(false);
        b4.setOpaque(false);


        pl1 = new JButton("User Information");
        pl1.setBounds(40, 300, 250, 35);
        pl1.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        pl1.setForeground(Color.black);
        pl1.setFocusPainted(false);
        pl1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pl1.setContentAreaFilled(false);
        pl1.setBorderPainted(false);

        b5 = new JButton();
        b5.setBounds(400, 80, 210, 190);
        b5.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b5.setFocusPainted(false);
        b5.setBorder(BorderFactory.createEmptyBorder());
        b5.setContentAreaFilled(false);
        b5.setOpaque(false);


        pl2 = new JButton("Add User");
        pl2.setBounds(370, 300, 250, 35);
        pl2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        pl2.setForeground(Color.black);
        pl2.setFocusPainted(false);
        pl2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pl2.setContentAreaFilled(false);
        pl2.setBorderPainted(false);

        b6 = new JButton();
        b6.setBounds(80, 420, 210, 210);
        b6.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b6.setFocusPainted(false);
        b6.setBorder(BorderFactory.createEmptyBorder());
        b6.setContentAreaFilled(false);
        b6.setOpaque(false);


        pl3 = new JButton("Add New Admin");
        pl3.setBounds(40, 650, 250, 35);
        pl3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        pl3.setForeground(Color.black);
        pl3.setFocusPainted(false);
        pl3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pl3.setContentAreaFilled(false);
        pl3.setBorderPainted(false);


        frame.add(b1);
        frame.add(b2);
        frame.add(b3);
        frame.add(b4);
        frame.add(b5);
        frame.add(b6);

        frame.add(pl1);
        frame.add(pl2);
        frame.add(pl3);

        frame.add(l1);

        frame.setSize(1228, 768);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b1) {
                    frame.setVisible(false);
                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b2) {
                    frame.setState(Frame.ICONIFIED);
                }

            }
        });

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b3) {
                    new Login("textField1", "textField2");
                    frame.setVisible(false);
                }
            }
        });

        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b4) {

                    new AdminDashBoard1(textField1);
                    frame.setVisible(false);
                }
            }
        });
        pl1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == pl1) {

                    new AdminDashBoard1(textField1);
                    frame.setVisible(false);

                }
            }
        });

        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b5) {

                    new AdminDashBoard2(textField1);
                    frame.setVisible(false);
                }
            }
        });
        pl2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == pl2) {

                    new AdminDashBoard2(textField1);

                    frame.setVisible(false);
                }
            }
        });


        b6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b6) {
                    new AdminDashBoard3(textField1);
                    frame.setVisible(false);
                }
            }
        });
        pl3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == pl3) {
                    new AdminDashBoard3(textField1);
                    frame.setVisible(false);
                }
            }
        });

    }
}
