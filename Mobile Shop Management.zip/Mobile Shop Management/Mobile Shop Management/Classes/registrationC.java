package Classes;

import Interfaces.iRegistrationOperation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static javax.swing.JOptionPane.showMessageDialog;

public class registrationC implements iRegistrationOperation {

    String textField1;
    String textField2;
    String textField3;

    int s = 0;

    registrationC (String textField1, String textField3, String textField2) {
        this.textField1 = textField1;
        this.textField3 = textField3;
        this.textField2 = textField2;

    }

    public void registration(String textField1, String textField3, String textField2) {
        try {

            File file = new File(".\\Data\\user_data.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);

            LocalDateTime myDateObj = LocalDateTime.now();
            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy");

            String timeAndDate = myDateObj.format(myFormatObj);

            pw.println("User Name : " + textField1);
            pw.println("Password : " + textField3);
            pw.println("Email : " + textField2);
            pw.println("Time & Date : " + timeAndDate);
            pw.println("===============================================");
            pw.close();

            showMessageDialog(null,
                    "Registration Successfully Completed \n         You Can Log In now ",
                    "Registration Complete", 1);
            new Login("textField1", "textField2");
            s = 1;

        } catch (Exception ex) {
            System.out.print(ex);
        }
    }
}

